#ionic-tutorial-tabs


This code is part of a tutorial on how group items with collection-repeat.

Read the tutorial here: [How To Create A Different Tab Layout Per Platform In Ionic](http://gonehybrid.com/how-to-create-a-different-tab-layout-per-platform-in-ionic/)

For more tutorials on Ionic, check out my blog [Gone Hybrid](http://gonehybrid.com).
