<?php
$host = 'localhost';
$user = 'root';
$password = '';
$db = 'hms';
$con = mysqli_connect($host, $user, $password, $db) or die('connection error!');
?>